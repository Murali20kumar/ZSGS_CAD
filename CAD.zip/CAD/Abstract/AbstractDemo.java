package Abstract;

abstract class HotelService{
    protected String type;

    public HotelService(String type){
        this.type = type;
    }

    public void printType(){
        System.out.println("Service Type: " + type );
    }

    public abstract void book(String name);
}

class GymBooking extends HotelService{
    public GymBooking(){
        super("Gym");
    }

    public void book(String name){
        System.out.println("Gym session booked for : " + name);
    }
}

public class AbstractDemo {
    public static void main(String[]args){
        HotelService service = new GymBooking();
        service.printType();
        service.book("Dorian");
    }
}
