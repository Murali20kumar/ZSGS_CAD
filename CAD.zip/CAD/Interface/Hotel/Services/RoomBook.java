package Hotel.Services;

public class RoomBook implements HotelServices {
    public void bookService(String serviceName) {
        System.out.println("Room booked for: " + serviceName);
    }

    public double getCost() {
        return 1000.0;
    }
}