package Hotel.Services;

public interface HotelServices{
    void bookService(String CustomerName);
    double getCost();
}

