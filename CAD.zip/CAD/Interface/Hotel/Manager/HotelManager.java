package Hotel.Manager;

import Hotel.Services.HotelServices;
import Hotel.Services.RoomBook;

public class HotelManager {
    public void manageBookings(HotelServices service, String customerName) {
        service.bookService(customerName);
        System.out.println("Total cost for " + customerName + " is: " + service.getCost());
    }

    public static void main(String[] args) {
        HotelManager hm = new HotelManager();
        HotelServices room = new RoomBook();
        hm.manageBookings(room, "Dorian");
    }
}