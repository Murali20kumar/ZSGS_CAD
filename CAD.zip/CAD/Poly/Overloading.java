package Poly;

public class Overloading {
    public void greet(String name) {
        System.out.println("Hello " + name);
    }

    public void greet(String name, int times) {
        for (int i = 0; i < times; i++) {
            System.out.println("Hello " + name);
        }
    }

    public static void main(String[] args) {
        Overloading obj = new Overloading();
        obj.greet("Murali");
        obj.greet("Murali", 3);
    }

}