package Poly;

class Booking {
      public void book(String name) {
        System.out.println("Generic booking for " + name);
    }

}

class RoomBooking extends Booking{
    @Override
    public void book(String name){
        super.book(name);
        System.out.println("Room booked for " + name);
    }
}

public class Overriding {
    public static void main(String[]args){
        Booking bk = new RoomBooking();
        bk.book("Monster");
    }
}
